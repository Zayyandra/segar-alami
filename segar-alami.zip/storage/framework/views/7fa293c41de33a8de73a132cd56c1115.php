<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['title' => 'Penjualan','subtitle' => 'Manajemen transaksi penjualan Segar Alami.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Penjualan','subtitle' => 'Manajemen transaksi penjualan Segar Alami.']); ?>

    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm px-6 py-5 flex items-center gap-4">
            <div class="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center shrink-0">
                <svg class="w-5 h-5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/>
                </svg>
            </div>
            <div>
                <p class="text-xs text-slate-500 uppercase tracking-wider mb-1">Total Omzet Hari Ini</p>
                <p class="text-2xl font-bold text-slate-900">Rp <?php echo e(number_format($totalOmzetHariIni, 0, ',', '.')); ?></p>
                <p class="text-xs text-emerald-600 font-medium mt-1"><?php echo e($transaksiHariIni ?? 0); ?> transaksi hari ini</p>
            </div>
        </div>

        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm px-6 py-5 flex items-center gap-4">
            <div class="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center shrink-0">
                <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
                </svg>
            </div>
            <div>
                <p class="text-xs text-slate-500 uppercase tracking-wider mb-1">Produk Terjual Hari Ini</p>
                <p class="text-2xl font-bold text-slate-900"><?php echo e(number_format($totalProdukTerjual ?? 0, 0, ',', '.')); ?> <span class="text-sm font-normal text-slate-400">Item</span></p>
                <p class="text-xs text-blue-600 font-medium mt-1"><?php echo e(now()->translatedFormat('d F Y')); ?></p>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
            <div>
                <h3 class="text-sm font-bold text-slate-900">Daftar Transaksi</h3>
                <p class="text-xs text-slate-400 mt-0.5"><?php echo e(now()->translatedFormat('d F Y')); ?></p>
            </div>
            <a href="<?php echo e(route('app.penjualan.create')); ?>"
               class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-medium transition">
                + Catat Penjualan
            </a>
        </div>

        <div class="px-6 py-3 border-b border-slate-100 flex gap-3">
            <form method="GET" action="<?php echo e(route('app.penjualan.index')); ?>" class="flex flex-1 gap-3">
                <div class="relative flex-1">
                    <svg class="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-4.35-4.35M11 19a8 8 0 100-16 8 8 0 000 16z"/>
                    </svg>
                    <input type="search" name="q" value="<?php echo e(request('q')); ?>" placeholder="Cari keterangan transaksi..."
                           class="w-full pl-10 px-3 py-2 rounded-lg border border-slate-200 text-sm focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none">
                </div>
                <input type="date" name="tanggal" value="<?php echo e(request('tanggal')); ?>" onchange="this.form.submit()"
                       class="px-3 py-2 rounded-lg border border-slate-200 text-sm bg-white focus:border-emerald-500 focus:outline-none">
                <?php if(request()->anyFilled(['q', 'tanggal'])): ?>
                    <a href="<?php echo e(route('app.penjualan.index')); ?>" class="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-100 transition">Reset</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-slate-50">
                    <tr class="text-left text-xs uppercase tracking-wide text-slate-500">
                        <th class="px-6 py-3 font-medium">Tanggal</th>
                        <th class="px-6 py-3 font-medium">Dicatat Oleh</th>
                        <th class="px-6 py-3 font-medium">Keterangan</th>
                        <th class="px-6 py-3 font-medium text-right">Total</th>
                        <th class="px-6 py-3 font-medium text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__empty_1 = true; $__currentLoopData = $penjualans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-slate-50/50">
                            <td class="px-6 py-4 text-sm text-slate-700 whitespace-nowrap"><?php echo e($item->tanggal->format('d M Y')); ?></td>
                            <td class="px-6 py-4 text-sm text-slate-600"><?php echo e($item->user->name); ?></td>
                            <td class="px-6 py-4 text-sm text-slate-500"><?php echo e($item->keterangan ?? '—'); ?></td>
                            <td class="px-6 py-4 text-right text-sm font-bold tabular-nums text-slate-900">
                                Rp <?php echo e(number_format($item->total, 0, ',', '.')); ?>

                            </td>
                            <td class="px-6 py-4 text-right">
                                <div class="inline-flex items-center gap-3">
                                    <a href="<?php echo e(route('app.penjualan.show', $item)); ?>"
                                       class="text-sm font-medium text-emerald-600 hover:text-emerald-700">Detail</a>
                                    <a href="<?php echo e(route('app.penjualan.edit', $item)); ?>"
                                       class="text-sm font-medium text-blue-600 hover:text-blue-700">Edit</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="px-6 py-16 text-center text-sm text-slate-400">
                                Belum ada transaksi.
                                <a href="<?php echo e(route('app.penjualan.create')); ?>" class="text-emerald-600 hover:underline">Catat sekarang.</a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($penjualans->hasPages()): ?>
            <div class="px-6 py-4 border-t border-slate-100"><?php echo e($penjualans->links()); ?></div>
        <?php endif; ?>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH C:\Users\ACER\Herd\segar-alami\resources\views/admin/penjualan/index.blade.php ENDPATH**/ ?>