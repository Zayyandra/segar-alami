<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['title' => 'Dashboard','subtitle' => 'Dashboard Sistem Penjualan dan Persediaan UMKM Segar Alami']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Dashboard','subtitle' => 'Dashboard Sistem Penjualan dan Persediaan UMKM Segar Alami']); ?>

    
    <div class="bg-gradient-to-r from-emerald-50 via-emerald-50 to-teal-50 border border-emerald-100
                rounded-2xl px-8 py-5 mb-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div class="flex items-center gap-4">
            <div class="w-12 h-12 rounded-full bg-emerald-500 flex items-center justify-center shrink-0 shadow-md shadow-emerald-200">
                <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"/>
                </svg>
            </div>
            <div>
                <h2 class="text-lg font-bold text-slate-900">Selamat datang, <?php echo e(auth()->user()->name); ?></h2>
                <p class="text-sm text-slate-600">Berikut adalah ringkasan operasional hari ini.</p>
            </div>
        </div>
        <div class="text-right shrink-0">
            <p class="text-xs font-bold text-emerald-700 uppercase tracking-wider">Segar Alami</p>
            <p class="text-sm text-slate-700"><?php echo e(now()->translatedFormat('l, d F Y')); ?></p>
        </div>
    </div>

    
    <?php if($expiredAlert->count()): ?>
        <div class="rounded-xl border border-red-200 bg-red-50 px-5 py-4 mb-6">
            <p class="text-sm font-semibold text-red-700 mb-2">
                ⚠ <?php echo e($expiredAlert->count()); ?> bahan baku perlu diperhatikan
            </p>
            <div class="space-y-1.5">
                <?php $__currentLoopData = $expiredAlert; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center justify-between text-xs text-red-700">
                        <span><?php echo e($item->bahanBaku->nama); ?>

                            <?php if($item->nama_supplier): ?>
                                <span class="text-red-400">(<?php echo e($item->nama_supplier); ?>)</span>
                            <?php endif; ?>
                        </span>
                        <?php if(\Carbon\Carbon::parse($item->tanggal_kadaluarsa)->lt(today())): ?>
                            <span class="font-semibold bg-red-100 px-2 py-0.5 rounded">Sudah kadaluarsa</span>
                        <?php else: ?>
                            <span class="text-red-600">Exp: <?php echo e(\Carbon\Carbon::parse($item->tanggal_kadaluarsa)->format('d M Y')); ?>

                                (<?php echo e(\Carbon\Carbon::parse($item->tanggal_kadaluarsa)->diffForHumans()); ?>)
                            </span>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>

    
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">

        
        <div class="bg-emerald-700 rounded-2xl shadow-md shadow-emerald-200 px-5 py-5">
            <p class="text-xs text-emerald-300 uppercase tracking-wider mb-2">
                Pendapatan <?php echo e(now()->translatedFormat('F Y')); ?>

            </p>
            <p class="text-2xl font-bold text-white leading-tight">
                Rp <?php echo e(number_format($pendapatanBulanIni, 0, ',', '.')); ?>

            </p>
            <p class="text-xs text-emerald-300 mt-2"><?php echo e($transaksiHariIni); ?> transaksi hari ini</p>
            <p class="text-xs text-emerald-400 mt-1">Diperbarui: <?php echo e(now()->format('H:i')); ?></p>
        </div>

        
        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm px-5 py-5">
            <p class="text-xs text-slate-500 uppercase tracking-wider mb-2">
                Produk Terjual <?php echo e(now()->translatedFormat('F')); ?>

            </p>
            <p class="text-2xl font-bold text-slate-900 leading-tight">
                <?php echo e(number_format($produkTerjualBulanIni, 0, ',', '.')); ?>

                <span class="text-sm font-medium text-slate-500">Item</span>
            </p>
            <p class="text-xs font-medium text-emerald-600 mt-2">Bulan berjalan</p>
            <p class="text-xs text-slate-400 mt-1">Diperbarui: <?php echo e(now()->format('H:i')); ?></p>
        </div>

        
        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm px-5 py-5">
            <p class="text-xs text-slate-500 uppercase tracking-wider mb-2">Produk Aktif</p>
            <p class="text-2xl font-bold text-slate-900 leading-tight">
                <?php echo e($totalProdukAktif); ?> <span class="text-sm font-medium text-slate-500">Produk</span>
            </p>
            <p class="text-xs text-slate-500 mt-2"><?php echo e($totalVarianAktif); ?> varian tersedia</p>
            <p class="text-xs text-slate-400 mt-1">Diperbarui: <?php echo e(now()->format('H:i')); ?></p>
        </div>

        
        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm px-5 py-5">
            <p class="text-xs text-slate-500 uppercase tracking-wider mb-2">Bahan Baku Aktif</p>
            <p class="text-2xl font-bold text-slate-900 leading-tight">
                <?php echo e($totalBahanBaku); ?> <span class="text-sm font-medium text-slate-500">Jenis</span>
            </p>
            <?php if($expiredAlert->count()): ?>
                <p class="text-xs font-medium text-red-600 mt-2">⚠ <?php echo e($expiredAlert->count()); ?> perlu dicek</p>
            <?php else: ?>
                <p class="text-xs font-medium text-emerald-600 mt-2">✓ Semua aman</p>
            <?php endif; ?>
            <p class="text-xs text-slate-400 mt-1">Diperbarui: <?php echo e(now()->format('H:i')); ?></p>
        </div>
    </div>

    
    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
            <h3 class="text-sm font-bold text-slate-900">Transaksi Terbaru</h3>
            <a href="<?php echo e(route('app.penjualan.index')); ?>"
               class="text-sm font-medium text-emerald-600 hover:text-emerald-700">Lihat semua →</a>
        </div>
        <div class="overflow-x-auto">
        <table class="w-full min-w-[640px]">
            <thead class="bg-slate-50">
                <tr class="text-left text-xs uppercase tracking-wide text-slate-500">
                    <th class="px-6 py-3 font-medium">Tanggal</th>
                    <th class="px-6 py-3 font-medium">Dicatat Oleh</th>
                    <th class="px-6 py-3 font-medium">Keterangan</th>
                    <th class="px-6 py-3 font-medium text-right">Total</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
                <?php $__empty_1 = true; $__currentLoopData = $transaksiTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-slate-50/50">
                        <td class="px-6 py-4 text-sm text-slate-700"><?php echo e($t->tanggal->format('d M Y')); ?></td>
                        <td class="px-6 py-4 text-sm text-slate-600"><?php echo e($t->user->name); ?></td>
                        <td class="px-6 py-4 text-sm text-slate-500"><?php echo e($t->keterangan ?? '—'); ?></td>
                        <td class="px-6 py-4 text-right text-sm font-semibold tabular-nums text-slate-900">
                            Rp <?php echo e(number_format($t->total, 0, ',', '.')); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="px-6 py-10 text-center text-sm text-slate-400">
                            Belum ada transaksi.
                            <a href="<?php echo e(route('app.penjualan.create')); ?>" class="text-emerald-600 hover:underline">Catat sekarang.</a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH C:\Users\ACER\Herd\segar-alami\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>