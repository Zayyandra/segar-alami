<?php
    $user = auth()->user();
    $isOwner = $user->hasRole('owner');
    $isAdmin = $user->hasRole('admin');

    $initials = collect(explode(' ', $user->name))
        ->take(2)
        ->map(fn($w) => strtoupper($w[0]))
        ->join('');
    $roleName = $user->getRoleNames()->first() ?? 'user';

    $expiredCount = 0;
    if ($isAdmin) {
        $expiredCount = \App\Models\BahanMasuk::whereNotNull('tanggal_kadaluarsa')
            ->where(function ($q) {
                $q->whereDate('tanggal_kadaluarsa', '<', today())->orWhere(function ($q2) {
                    $q2->whereDate('tanggal_kadaluarsa', '>=', today())->whereDate(
                        'tanggal_kadaluarsa',
                        '<=',
                        today()->addDays(7),
                    );
                });
            })
            ->count();
    }

    if ($isAdmin) {
        $groups = [
            [
                'label' => null,
                'items' => [
                    ['route' => 'app.dashboard', 'label' => 'Dashboard', 'icon' => 'grid'],
                    ['route' => 'app.penjualan.index', 'label' => 'Penjualan', 'icon' => 'receipt'],
                ],
            ],
            [
                'label' => 'Katalog',
                'items' => [
                    ['route' => 'app.kategori.index', 'label' => 'Kategori', 'icon' => 'tag'],
                    ['route' => 'app.produk.index', 'label' => 'Produk', 'icon' => 'bag'],
                    ['route' => 'app.varian-produk.index', 'label' => 'Varian Produk', 'icon' => 'layers'],
                    [
                        'route' => 'app.konversi-produk.index',
                        'label' => 'Konversi Produk',
                        'icon' => 'arrows-right-left',
                    ],
                ],
            ],
            [
                'label' => 'Inventaris',
                'items' => [
                    ['route' => 'app.bahan-baku.index', 'label' => 'Bahan Baku', 'icon' => 'beaker'],
                    ['route' => 'app.bahan-masuk.index', 'label' => 'Bahan Masuk', 'icon' => 'inbox'],
                    ['route' => 'app.bahan-keluar.index', 'label' => 'Bahan Keluar', 'icon' => 'outbox'],
                ],
            ],
            [
                'label' => 'Analitik',
                'items' => [['route' => 'app.masa-simpan.index', 'label' => 'Masa Simpan', 'icon' => 'clock']],
            ],
        ];
    } else {
        $groups = [
            [
                'label' => null,
                'items' => [['route' => 'app.dashboard', 'label' => 'Dashboard', 'icon' => 'grid']],
            ],
            [
                'label' => 'Laporan',
                'items' => [
                    ['route' => 'app.laporan.penjualan', 'label' => 'Laporan Penjualan', 'icon' => 'chart'],
                    ['route' => 'app.laporan.persediaan', 'label' => 'Laporan Persediaan', 'icon' => 'clipboard'],
                ],
            ],
            [
                'label' => 'Manajemen',
                'items' => [['route' => 'app.users.index', 'label' => 'Manajemen Pengguna', 'icon' => 'users']],
            ],
        ];
    }
?>

<aside
    class="fixed inset-y-0 left-0 z-50 w-64 flex flex-col shrink-0 min-h-screen
           transform transition-transform duration-200 ease-in-out
           lg:static lg:translate-x-0"
    :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'"
    style="background-color: #1a2035;">

    
    <button type="button" @click="sidebarOpen = false"
        class="lg:hidden absolute top-4 right-4 w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/10 transition">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
        </svg>
    </button>

    
    <div class="px-4 py-6 flex justify-center">
        <div class="w-24 h-24 rounded-2xl bg-white flex items-center justify-center overflow-hidden p-2 shadow-sm">
            <img src="<?php echo e(asset('images/logo-segar-alami.jpeg')); ?>" alt="Logo Segar Alami"
                class="w-full h-full object-contain">
        </div>
    </div>

    
    <nav class="flex-1 px-3 space-y-4 overflow-y-auto pb-4">
        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <?php if($group['label']): ?>
                    <p class="px-4 mb-1 text-[10px] font-bold uppercase tracking-widest"
                        style="color: rgba(255,255,255,0.25);">
                        <?php echo e($group['label']); ?>

                    </p>
                <?php endif; ?>
                <div class="space-y-0.5">
                    <?php $__currentLoopData = $group['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $exists = \Route::has($item['route']);
                            $pattern =
                                $item['route'] === 'app.dashboard'
                                    ? 'app.dashboard'
                                    : (str_ends_with($item['route'], '.penjualan') ||
                                    str_ends_with($item['route'], '.persediaan')
                                        ? $item['route']
                                        : rtrim(preg_replace('/\.index$/', '', $item['route']), '.') . '.*');
                            $active = $exists && request()->routeIs($pattern);
                            $href = $exists ? route($item['route']) : '#';
                        ?>
                        <a href="<?php echo e($href); ?>"
                            class="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-150
                                  <?php echo e($active ? 'text-emerald-400' : 'text-slate-400 hover:text-white hover:bg-white/5'); ?>"
                            <?php if($active): ?> style="background: rgba(16,185,129,0.12);" <?php endif; ?>>
                            <?php if (isset($component)) { $__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icon','data' => ['name' => $item['icon'],'class' => 'w-5 h-5 shrink-0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item['icon']),'class' => 'w-5 h-5 shrink-0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd)): ?>
<?php $attributes = $__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd; ?>
<?php unset($__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd)): ?>
<?php $component = $__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd; ?>
<?php unset($__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd); ?>
<?php endif; ?>
                            <span class="flex-1"><?php echo e($item['label']); ?></span>
                            <?php if($item['route'] === 'app.bahan-masuk.index' && $expiredCount > 0): ?>
                                <span
                                    class="inline-flex items-center justify-center w-4 h-4 rounded-full bg-red-500 text-white text-[10px] font-bold leading-none">
                                    <?php echo e($expiredCount > 9 ? '9+' : $expiredCount); ?>

                                </span>
                            <?php endif; ?>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </nav>

    
    <div class="p-3" style="border-top: 1px solid rgba(255,255,255,0.07);">
        <div class="flex items-center gap-3 px-3 py-2.5 mb-1 rounded-xl" style="background: rgba(255,255,255,0.04);">
            <div class="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shrink-0"
                style="background: rgba(16,185,129,0.2); color: #34d399;">
                <?php echo e($initials); ?>

            </div>
            <div class="min-w-0">
                <p class="text-sm font-medium text-white truncate"><?php echo e($user->name); ?></p>
                <p class="text-xs capitalize" style="color: #34d399;"><?php echo e($roleName); ?></p>
            </div>
        </div>

        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit"
                class="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium
                       text-slate-400 hover:text-white hover:bg-white/5 transition-all duration-150">
                <?php if (isset($component)) { $__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icon','data' => ['name' => 'logout','class' => 'w-5 h-5 shrink-0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'logout','class' => 'w-5 h-5 shrink-0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd)): ?>
<?php $attributes = $__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd; ?>
<?php unset($__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd)): ?>
<?php $component = $__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd; ?>
<?php unset($__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd); ?>
<?php endif; ?>
                <span>Keluar</span>
            </button>
        </form>
    </div>

</aside>
<?php /**PATH C:\Users\ACER\Herd\segar-alami\resources\views/components/admin/sidebar.blade.php ENDPATH**/ ?>