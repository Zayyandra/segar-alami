<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['title' => 'Laporan Masa Simpan','subtitle' => 'Pemantauan masa simpan bahan baku berdasarkan metode FEFO (First Expired First Out).']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Laporan Masa Simpan','subtitle' => 'Pemantauan masa simpan bahan baku berdasarkan metode FEFO (First Expired First Out).']); ?>
    <div class="space-y-6">

        

        
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
            <a href="<?php echo e(route('app.masa-simpan.index')); ?>"
               class="bg-white rounded-2xl p-4 shadow-sm border <?php echo e(!$status ? 'border-emerald-400 ring-1 ring-emerald-400' : 'border-gray-100'); ?>">
                <p class="text-xs text-gray-500 font-medium uppercase tracking-wide">Semua</p>
                <p class="text-2xl font-bold text-gray-900 mt-1"><?php echo e($counts['semua']); ?></p>
            </a>
            <a href="<?php echo e(route('app.masa-simpan.index', ['status' => 'kadaluarsa'])); ?>"
               class="bg-white rounded-2xl p-4 shadow-sm border <?php echo e($status === 'kadaluarsa' ? 'border-red-400 ring-1 ring-red-400' : 'border-gray-100'); ?>">
                <p class="text-xs text-gray-500 font-medium uppercase tracking-wide">Sudah Kedaluwarsa</p>
                <p class="text-2xl font-bold text-red-600 mt-1"><?php echo e($counts['kadaluarsa']); ?></p>
            </a>
            <a href="<?php echo e(route('app.masa-simpan.index', ['status' => 'mendekati'])); ?>"
               class="bg-white rounded-2xl p-4 shadow-sm border <?php echo e($status === 'mendekati' ? 'border-amber-400 ring-1 ring-amber-400' : 'border-gray-100'); ?>">
                <p class="text-xs text-gray-500 font-medium uppercase tracking-wide">Mendekati Kedaluwarsa</p>
                <p class="text-2xl font-bold text-amber-600 mt-1"><?php echo e($counts['mendekati']); ?></p>
            </a>
            <a href="<?php echo e(route('app.masa-simpan.index', ['status' => 'aman'])); ?>"
               class="bg-white rounded-2xl p-4 shadow-sm border <?php echo e($status === 'aman' ? 'border-emerald-400 ring-1 ring-emerald-400' : 'border-gray-100'); ?>">
                <p class="text-xs text-gray-500 font-medium uppercase tracking-wide">Aman</p>
                <p class="text-2xl font-bold text-emerald-600 mt-1"><?php echo e($counts['aman']); ?></p>
            </a>
        </div>

        
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-100">
                <h2 class="font-semibold text-gray-800">Daftar Bahan Baku Masuk</h2>
                <p class="text-xs text-gray-400 mt-0.5">Diurutkan berdasarkan tanggal kedaluwarsa terdekat (FEFO)</p>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead>
                        <tr class="border-b border-gray-100 bg-gray-50">
                            <th class="text-left px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Bahan Baku</th>
                            <th class="text-left px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Jumlah</th>
                            <th class="text-left px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Tanggal Masuk</th>
                            <th class="text-left px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Tanggal Kedaluwarsa</th>
                            <th class="text-left px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Sisa Hari</th>
                            <th class="text-left px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Status</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-50">
                        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-50 transition-colors">
                                <td class="px-6 py-4">
                                    <p class="font-medium text-gray-900"><?php echo e($item->bahanBaku->nama); ?></p>
                                    <p class="text-xs text-gray-400"><?php echo e($item->bahanBaku->satuan); ?></p>
                                </td>
                                <td class="px-6 py-4 text-gray-700">
                                    <?php echo e($item->jumlah); ?> <?php echo e($item->bahanBaku->satuan); ?>

                                </td>
                                <td class="px-6 py-4 text-gray-600">
                                    <?php echo e(\Carbon\Carbon::parse($item->tanggal_masuk)->format('d M Y')); ?>

                                </td>
                                <td class="px-6 py-4 text-gray-600">
                                    <?php echo e(\Carbon\Carbon::parse($item->tanggal_kadaluarsa)->format('d M Y')); ?>

                                </td>
                                <td class="px-6 py-4 font-medium
                                    <?php echo e($item->status === 'kadaluarsa' ? 'text-red-600' : ($item->status === 'mendekati' ? 'text-amber-600' : 'text-emerald-600')); ?>">
                                    <?php echo e($item->sisa_hari); ?>

                                </td>
                                <td class="px-6 py-4">
                                    <?php if($item->status === 'kadaluarsa'): ?>
                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-700">
                                            Sudah Kedaluwarsa
                                        </span>
                                    <?php elseif($item->status === 'mendekati'): ?>
                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-700">
                                            Mendekati Kedaluwarsa
                                        </span>
                                    <?php else: ?>
                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-700">
                                            Aman
                                        </span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="px-6 py-12 text-center text-gray-400">
                                    Tidak ada data bahan baku dengan filter ini.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH C:\Users\ACER\Herd\segar-alami\resources\views/admin/masa-simpan/index.blade.php ENDPATH**/ ?>