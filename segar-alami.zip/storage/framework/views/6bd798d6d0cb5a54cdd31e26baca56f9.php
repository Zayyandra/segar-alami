<?php echo csrf_field(); ?>

<div class="space-y-5" x-data="{
    satuanMap: <?php echo e(Js::from($bahanBakus->pluck('satuan', 'id'))); ?>,
    items: <?php echo e(isset($existingKonversi) && $existingKonversi->count()
        ? Js::from($existingKonversi->map(fn($k) => [
            'bahan_baku_id'     => (string) $k->bahan_baku_id,
            'jumlah_per_satuan' => (string) $k->jumlah_per_satuan,
          ]))
        : '[{ bahan_baku_id: \'\', jumlah_per_satuan: \'\' }]'); ?>,
    addItem() {
        this.items.push({ bahan_baku_id: '', jumlah_per_satuan: '' })
    },
    removeItem(index) {
        if (this.items.length > 1) this.items.splice(index, 1)
    },
    getSatuan(id) {
        return this.satuanMap[id] ?? '—'
    }
}">

    
    <div>
        <label class="block text-sm font-medium text-slate-700 mb-1.5">
            Varian Produk <span class="text-red-500">*</span>
        </label>

        <?php if(isset($konversiProduk) && $konversiProduk->exists): ?>
            
            <input type="hidden" name="varian_produk_id" value="<?php echo e($konversiProduk->varian_produk_id); ?>">
            <div class="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-600">
                <?php echo e($konversiProduk->varianProduk->produk->nama); ?> —
                <?php echo e($konversiProduk->varianProduk->nama_varian); ?>

                <?php echo e($konversiProduk->varianProduk->ukuran ? '(' . $konversiProduk->varianProduk->ukuran . ')' : ''); ?>

            </div>
        <?php else: ?>
            
            <select name="varian_produk_id"
                class="w-full rounded-lg border border-slate-200 px-3 py-2.5 text-sm bg-white
                       focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none
                       <?php $__errorArgs = ['varian_produk_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <option value="">— Pilih varian produk —</option>
                <?php $__currentLoopData = $varianProduks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $varian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($varian->id); ?>" <?php if(old('varian_produk_id') == $varian->id): echo 'selected'; endif; ?>>
                        <?php echo e($varian->produk->nama); ?> —
                        <?php echo e($varian->nama_varian); ?><?php echo e($varian->ukuran ? ' (' . $varian->ukuran . ')' : ''); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['varian_produk_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php endif; ?>
    </div>

    
    <div class="space-y-3">
        <div class="flex items-center justify-between">
            <label class="text-sm font-medium text-slate-700">
                Bahan Baku <span class="text-red-500">*</span>
            </label>
            <button type="button" @click="addItem()"
                class="text-xs font-medium text-emerald-600 hover:text-emerald-700 transition">
                + Tambah Bahan
            </button>
        </div>

        <div class="text-xs text-slate-400 mb-1">
            Jumlah bahan yang dibutuhkan per 1 unit varian produk terjual
        </div>

        <template x-for="(item, index) in items" :key="index">
            <div class="flex gap-3 items-center">

                
                <div class="flex-1">
                    <select :name="'items[' + index + '][bahan_baku_id]'"
                        x-model="item.bahan_baku_id"
                        class="w-full rounded-lg border border-slate-200 px-3 py-2.5 text-sm bg-white
                               focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none">
                        <option value="">— Pilih bahan baku —</option>
                        <?php $__currentLoopData = $bahanBakus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($bb->id); ?>"><?php echo e($bb->nama); ?> (<?php echo e($bb->satuan); ?>)</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div class="w-36 relative">
                    <input type="number"
                        :name="'items[' + index + '][jumlah_per_satuan]'"
                        x-model="item.jumlah_per_satuan"
                        step="0.0001" min="0.0001"
                        placeholder="0.0000"
                        class="w-full rounded-lg border border-slate-200 px-3 py-2.5 pr-10 text-sm
                               focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none">
                    <span class="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400"
                        x-text="getSatuan(item.bahan_baku_id)"></span>
                </div>

                
                <button type="button" @click="removeItem(index)"
                    x-show="items.length > 1"
                    class="text-slate-300 hover:text-red-500 transition text-lg leading-none">
                    ✕
                </button>
            </div>
        </template>
    </div>

</div>

<div class="mt-8 flex items-center justify-end gap-3 border-t border-slate-100 pt-6">
    <a href="<?php echo e(route('app.konversi-produk.index')); ?>"
        class="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-100 transition">
        Batal
    </a>
    <button type="submit"
        class="px-5 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-medium transition">
        <?php echo e($submitLabel ?? 'Simpan'); ?>

    </button>
</div>
<?php /**PATH C:\Users\ACER\Herd\segar-alami\resources\views/admin/konversi-produk/_form.blade.php ENDPATH**/ ?>