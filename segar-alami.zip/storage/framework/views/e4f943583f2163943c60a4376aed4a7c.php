<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['title' => 'Detail Transaksi','subtitle' => 'Informasi lengkap tentang transaksi penjualan Segar Alami.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Detail Transaksi','subtitle' => 'Informasi lengkap tentang transaksi penjualan Segar Alami.']); ?>
    <div class="max-w-3xl mx-auto space-y-5">

        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">

            <div class="px-8 py-5 border-b border-slate-100 grid md:grid-cols-3 gap-4">
                <div>
                    <p class="text-xs text-slate-400 uppercase tracking-wider mb-1">Tanggal</p>
                    <p class="text-sm font-medium text-slate-800"><?php echo e($penjualan->tanggal->format('d M Y')); ?></p>
                </div>
                <div>
                    <p class="text-xs text-slate-400 uppercase tracking-wider mb-1">Dicatat Oleh</p>
                    <p class="text-sm font-medium text-slate-800"><?php echo e($penjualan->user->name); ?></p>
                </div>
                <div>
                    <p class="text-xs text-slate-400 uppercase tracking-wider mb-1">Keterangan</p>
                    <p class="text-sm font-medium text-slate-800"><?php echo e($penjualan->keterangan ?? '—'); ?></p>
                </div>
            </div>

            <div class="overflow-x-auto">
            <table class="w-full min-w-[560px]">
                <thead class="bg-slate-50">
                    <tr class="text-left text-xs uppercase tracking-wide text-slate-500">
                        <th class="px-6 py-3 font-medium">Produk</th>
                        <th class="px-6 py-3 font-medium text-center">Jumlah</th>
                        <th class="px-6 py-3 font-medium text-right">Harga Satuan</th>
                        <th class="px-6 py-3 font-medium text-right">Subtotal</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__currentLoopData = $penjualan->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-6 py-4">
                                <p class="text-sm font-medium text-slate-900"><?php echo e($detail->varianProduk->produk->nama); ?></p>
                                <p class="text-xs text-slate-500">
                                    <?php echo e($detail->varianProduk->nama_varian); ?>

                                    <?php if($detail->varianProduk->ukuran): ?>
                                        · <?php echo e($detail->varianProduk->ukuran); ?>

                                    <?php endif; ?>
                                </p>
                            </td>
                            <td class="px-6 py-4 text-center text-sm text-slate-700"><?php echo e($detail->jumlah); ?></td>
                            <td class="px-6 py-4 text-right text-sm tabular-nums text-slate-700">
                                Rp <?php echo e(number_format($detail->harga_satuan, 0, ',', '.')); ?>

                            </td>
                            <td class="px-6 py-4 text-right text-sm font-semibold tabular-nums text-slate-900">
                                Rp <?php echo e(number_format($detail->sub_total, 0, ',', '.')); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr class="border-t-2 border-slate-200">
                        <td colspan="3" class="px-6 py-4 text-right text-sm font-semibold text-slate-700">Total</td>
                        <td class="px-6 py-4 text-right text-base font-bold text-emerald-600">
                            Rp <?php echo e(number_format($penjualan->total, 0, ',', '.')); ?>

                        </td>
                    </tr>
                </tfoot>
            </table>
            </div>

            <div class="px-8 py-4 border-t border-slate-100 flex justify-end gap-3">
                <a href="<?php echo e(route('app.penjualan.index')); ?>"
                   class="px-5 py-2 rounded-lg border border-slate-200 text-sm font-medium text-slate-700 hover:bg-slate-50 transition">
                    Kembali
                </a>
                <a href="<?php echo e(route('app.penjualan.edit', $penjualan)); ?>"
                   class="px-5 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-medium transition">
                    Edit Transaksi
                </a>
            </div>
        </div>

        
        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div class="px-8 py-5 border-b border-slate-100">
                <p class="text-sm font-semibold text-slate-700">Estimasi Pemakaian Bahan Baku</p>
                <p class="text-xs text-slate-400 mt-0.5">Dihitung otomatis berdasarkan rasio konversi produk</p>
            </div>

            <?php if(count($estimasi) > 0): ?>
                <table class="w-full">
                    <thead class="bg-slate-50">
                        <tr class="text-left text-xs uppercase tracking-wide text-slate-500">
                            <th class="px-6 py-3 font-medium">Bahan Baku</th>
                            <th class="px-6 py-3 font-medium text-right">Estimasi Terpakai</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        <?php $__currentLoopData = $estimasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="px-6 py-4 text-sm text-slate-700"><?php echo e($item['nama']); ?></td>
                                <td class="px-6 py-4 text-right text-sm font-medium text-slate-900 tabular-nums">
                                    <?php echo e(number_format($item['total'], 2)); ?> <?php echo e($item['satuan']); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="px-8 py-5 text-sm text-slate-400">
                    Belum ada data konversi untuk produk-produk di transaksi ini.
                </div>
            <?php endif; ?>
        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH C:\Users\ACER\Herd\segar-alami\resources\views/admin/penjualan/show.blade.php ENDPATH**/ ?>