<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['title' => 'Laporan Persediaan','subtitle' => 'Pantau ketersediaan stok bahan baku secara real-time.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Laporan Persediaan','subtitle' => 'Pantau ketersediaan stok bahan baku secara real-time.']); ?>

    
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">

        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm px-5 py-5">
            <div class="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center mb-3">
                <svg class="w-5 h-5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                </svg>
            </div>
            <p class="text-xs text-slate-500 uppercase tracking-wider">Total Jenis</p>
            <p class="text-3xl font-bold text-slate-900 mt-1"><?php echo e($totalJenis); ?></p>
            <p class="text-xs text-slate-400 mt-1">Kategori Bahan Baku</p>
        </div>

        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm px-5 py-5">
            <div class="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center mb-3">
                <svg class="w-5 h-5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
            </div>
            <p class="text-xs text-slate-500 uppercase tracking-wider">Aman</p>
            <p class="text-3xl font-bold text-slate-900 mt-1"><?php echo e($jumlahAman); ?></p>
            <p class="text-xs text-emerald-600 mt-1">Persediaan Optimal</p>
        </div>

        <div class="bg-red-50 rounded-2xl border border-red-100 shadow-sm px-5 py-5">
            <div class="w-10 h-10 rounded-xl bg-red-100 flex items-center justify-center mb-3">
                <svg class="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
            </div>
            <p class="text-xs text-red-500 uppercase tracking-wider">Kritis</p>
            <p class="text-3xl font-bold text-red-600 mt-1"><?php echo e($jumlahKritis); ?></p>
            <p class="text-xs text-red-500 mt-1">Butuh Re-stock Segera</p>
        </div>

        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm px-5 py-5">
            <div class="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center mb-3">
                <svg class="w-5 h-5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
            </div>
            <p class="text-xs text-slate-500 uppercase tracking-wider">Total Nilai</p>
            <p class="text-2xl font-bold text-slate-900 mt-1">Rp <?php echo e(number_format($totalNilai, 0, ',', '.')); ?></p>
            <p class="text-xs text-slate-400 mt-1">Valuasi Stok Gudang</p>
        </div>
    </div>

    
    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div
            class="px-6 py-4 border-b border-slate-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <h3 class="text-sm font-bold text-slate-900">Rincian Persediaan</h3>
            <div class="flex flex-wrap items-center gap-3">
                <form method="GET" action="<?php echo e(route('app.laporan.persediaan')); ?>" class="flex gap-2">
                    <div class="relative">
                        <svg class="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
                            fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M21 21l-4.35-4.35M11 19a8 8 0 100-16 8 8 0 000 16z" />
                        </svg>
                        <input type="search" name="q" value="<?php echo e(request('q')); ?>"
                            placeholder="Cari bahan baku..."
                            class="pl-10 pr-3 py-2 rounded-lg border border-slate-200 text-sm
                   focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none">
                    </div>
                    <select name="kategori" onchange="this.form.submit()"
                        class="px-3 pr-8 py-2 rounded-lg border border-slate-200 text-sm bg-white
               focus:border-emerald-500 focus:outline-none">
                        <option value="" <?php if($kategori === ''): echo 'selected'; endif; ?>>Semua Kategori</option>
                        <option value="utama" <?php if($kategori === 'utama'): echo 'selected'; endif; ?>>Utama</option>
                        <option value="pendukung" <?php if($kategori === 'pendukung'): echo 'selected'; endif; ?>>Pendukung</option>
                    </select>
                    <select name="status" onchange="this.form.submit()"
                        class="min-w-[150px] px-3 pr-8 py-2 rounded-lg border border-slate-200 text-sm bg-white
               focus:border-emerald-500 focus:outline-none">
                        <option value="">Semua Status</option>
                        <option value="aman" <?php if(request('status') === 'aman'): echo 'selected'; endif; ?>>Aman</option>
                        <option value="kritis" <?php if(request('status') === 'kritis'): echo 'selected'; endif; ?>>Kritis</option>
                    </select>
                </form>
                <div class="flex items-center gap-2 text-xs text-slate-500">
                    <span class="inline-flex items-center gap-1">
                        <span class="w-2 h-2 rounded-full bg-emerald-500"></span> Aman
                    </span>
                    <span class="inline-flex items-center gap-1">
                        <span class="w-2 h-2 rounded-full bg-red-500"></span> Kritis
                    </span>
                </div>
                <a href="<?php echo e(route('app.laporan.persediaan.pdf')); ?>"
                    class="px-4 py-2 rounded-lg border border-slate-200 bg-white text-slate-700
                          text-sm font-medium hover:bg-slate-50 transition flex items-center gap-2 whitespace-nowrap">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                    </svg>
                    Export PDF
                </a>
            </div>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full min-w-[640px]">
                <thead class="bg-slate-50">
                    <tr class="text-left text-xs uppercase tracking-wide text-slate-500">
                        <th class="px-6 py-3 font-medium">Nama Bahan Baku</th>
                        <th class="px-6 py-3 font-medium">Stok Saat Ini</th>
                        <th class="px-6 py-3 font-medium">Stok Minimum</th>
                        <th class="px-6 py-3 font-medium">Status</th>
                        <th class="px-6 py-3 font-medium text-right">Nilai Stok</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__empty_1 = true; $__currentLoopData = $bahanBakus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $ss = $batch[$item->id]['ss'] ?? null;
                            $statusItem = $ss === null ? 'unknown' : ($item->stok_saat_ini <= $ss ? 'kritis' : 'aman');
                        ?>
                        <tr class="hover:bg-slate-50/50">
                            <td class="px-6 py-4">
                                <p class="text-sm font-medium text-slate-900"><?php echo e($item->nama); ?></p>
                                <p class="text-xs text-slate-500"><?php echo e(ucfirst($item->kategori_bb)); ?></p>
                            </td>
                            <td
                                class="px-6 py-4 text-sm <?php echo e($statusItem === 'kritis' ? 'text-red-600 font-semibold' : 'text-slate-700'); ?>">
                                <?php echo e(number_format($item->stok_saat_ini, 2, ',', '.')); ?> <?php echo e($item->satuan); ?>

                            </td>
                            <td class="px-6 py-4 text-sm text-slate-600">
                                <?php if($ss !== null): ?>
                                    <?php echo e(number_format($ss, 2, ',', '.')); ?> <?php echo e($item->satuan); ?>

                                <?php else: ?>
                                    <span class="text-slate-400 italic text-xs">Belum ada histori</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4">
                                <?php if($statusItem === 'aman'): ?>
                                    <span
                                        class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-50 text-emerald-700">Aman</span>
                                <?php elseif($statusItem === 'kritis'): ?>
                                    <span
                                        class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-red-50 text-red-700">Kritis</span>
                                <?php else: ?>
                                    <span
                                        class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-slate-100 text-slate-500">—</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 text-right text-sm font-medium tabular-nums text-slate-900">
                                Rp <?php echo e(number_format($item->nilai_stok, 0, ',', '.')); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="px-6 py-12 text-center text-sm text-slate-400">
                                Belum ada data bahan baku.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($bahanBakus->hasPages()): ?>
            <div class="px-6 py-4 border-t border-slate-100"><?php echo e($bahanBakus->links()); ?></div>
        <?php endif; ?>

        <div class="px-6 py-3 border-t border-slate-100 flex items-center justify-between">
            <p class="text-xs text-slate-400">
                Data diperbarui setiap kali stok diupdate. Terakhir: <?php echo e(now()->translatedFormat('d M Y, H:i')); ?> WIB
            </p>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH C:\Users\ACER\Herd\segar-alami\resources\views/owner/laporan-persediaan.blade.php ENDPATH**/ ?>