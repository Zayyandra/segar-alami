
<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['title' => 'Konversi Produk','subtitle' => 'Atur rasio kebutuhan bahan baku per satuan varian produk.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Konversi Produk','subtitle' => 'Atur rasio kebutuhan bahan baku per satuan varian produk.']); ?>

    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
            <h3 class="text-sm font-bold text-slate-900">Daftar Konversi Produk</h3>
            <a href="<?php echo e(route('app.konversi-produk.create')); ?>"
                class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-medium transition">
                + Tambah Konversi
            </a>
        </div>

        <div class="px-6 py-3 border-b border-slate-100">
            <form method="GET" action="<?php echo e(route('app.konversi-produk.index')); ?>" class="flex gap-3">
                <select name="varian_produk_id" onchange="this.form.submit()"
                    class="min-w-[220px] px-3 py-2 rounded-lg border border-slate-200 text-sm bg-white focus:border-emerald-500 focus:outline-none">
                    <option value="">Semua Varian Produk</option>
                    <?php $__currentLoopData = $varianProduks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $varian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($varian->id); ?>" <?php if(request('varian_produk_id') == $varian->id): echo 'selected'; endif; ?>>
                            <?php echo e($varian->produk->nama); ?> —
                            <?php echo e($varian->nama_varian); ?><?php echo e($varian->ukuran ? ' (' . $varian->ukuran . ')' : ''); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if(request()->filled('varian_produk_id')): ?>
                    <a href="<?php echo e(route('app.konversi-produk.index')); ?>"
                        class="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-100 transition">Reset</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-slate-50">
                    <tr class="text-left text-xs uppercase tracking-wide text-slate-500">
                        <th class="px-6 py-3 font-medium">Varian Produk</th>
                        <th class="px-6 py-3 font-medium">Bahan Baku</th>
                        <th class="px-6 py-3 font-medium text-right">Jumlah per Satuan</th>
                        <th class="px-6 py-3 font-medium text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__empty_1 = true; $__currentLoopData = $konversiProduks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-slate-50/50">
                            <td class="px-6 py-4">
                                <p class="text-sm font-semibold text-slate-900"><?php echo e($item->varianProduk->produk->nama); ?>

                                </p>
                                <p class="text-xs text-slate-400">
                                    <?php echo e($item->varianProduk->nama_varian); ?><?php echo e($item->varianProduk->ukuran ? ' (' . $item->varianProduk->ukuran . ')' : ''); ?>

                                </p>
                            </td>
                            <td class="px-6 py-4">
                                <p class="text-sm text-slate-700"><?php echo e($item->bahanBaku->nama); ?></p>
                                <p class="text-xs text-slate-400"><?php echo e($item->bahanBaku->satuan); ?></p>
                            </td>
                            <td class="px-6 py-4 text-sm text-right tabular-nums text-slate-700">
                                <?php echo e(rtrim(rtrim(number_format($item->jumlah_per_satuan, 4, '.', ''), '0'), '.')); ?>

                                <span class="text-slate-400 text-xs"><?php echo e($item->bahanBaku->satuan); ?></span>
                            </td>
                            <td class="px-6 py-4 text-right">
                                <div class="inline-flex items-center gap-3">
                                    <a href="<?php echo e(route('app.konversi-produk.edit', $item)); ?>"
                                        class="text-sm font-medium text-emerald-600 hover:text-emerald-700">Edit</a>
                                    <form method="POST" action="<?php echo e(route('app.konversi-produk.destroy', $item)); ?>"
                                        class="inline" data-confirm="Hapus konversi ini?">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit"
                                            class="text-sm font-medium text-red-500 hover:text-red-600">Hapus</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="px-6 py-16 text-center text-sm text-slate-400">
                                Belum ada data konversi produk.
                                <a href="<?php echo e(route('app.konversi-produk.create')); ?>"
                                    class="text-emerald-600 hover:underline">Tambahkan sekarang.</a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($konversiProduks->hasPages()): ?>
            <div class="px-6 py-4 border-t border-slate-100 flex items-center justify-between">
                <p class="text-xs text-slate-400">Menampilkan
                    <?php echo e($konversiProduks->firstItem()); ?>–<?php echo e($konversiProduks->lastItem()); ?> dari
                    <?php echo e($konversiProduks->total()); ?> konversi</p>
                <?php echo e($konversiProduks->links()); ?>

            </div>
        <?php endif; ?>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH C:\Users\ACER\Herd\segar-alami\resources\views/admin/konversi-produk/index.blade.php ENDPATH**/ ?>