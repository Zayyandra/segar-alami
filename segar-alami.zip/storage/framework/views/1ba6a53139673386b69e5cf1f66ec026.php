<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['title' => 'Dashboard','subtitle' => 'Dashboard Sistem Penjualan dan Persediaan UMKM Segar Alami']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Dashboard','subtitle' => 'Dashboard Sistem Penjualan dan Persediaan UMKM Segar Alami']); ?>

    
    <div class="bg-gradient-to-r from-emerald-50 via-emerald-50 to-teal-50 border border-emerald-100
                rounded-2xl px-8 py-5 mb-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div class="flex items-center gap-4">
            <div class="w-12 h-12 rounded-full bg-emerald-500 flex items-center justify-center shrink-0
                        shadow-md shadow-emerald-200">
                <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"/>
                </svg>
            </div>
            <div>
                <h2 class="text-lg font-bold text-slate-900">Selamat datang, <?php echo e(auth()->user()->name); ?></h2>
                <p class="text-sm text-slate-600">Berikut adalah ringkasan operasional Anda hari ini.</p>
            </div>
        </div>
        <div class="text-right shrink-0">
            <p class="text-xs font-bold text-emerald-700 uppercase tracking-wider">Segar Alami</p>
            <p class="text-sm text-slate-700"><?php echo e(now()->translatedFormat('l, d F Y')); ?></p>
        </div>
    </div>

    
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">

        
        <div class="bg-emerald-700 rounded-2xl shadow-md shadow-emerald-200 px-5 py-5">
            <p class="text-xs text-emerald-300 uppercase tracking-wider mb-2">Total Penjualan Bulan Ini</p>
            <p class="text-2xl font-bold text-white leading-tight">
                Rp <?php echo e(number_format($totalBulanIni, 0, ',', '.')); ?>

            </p>
            <?php if($persenChange != 0): ?>
                <p class="text-xs font-medium <?php echo e($persenChange >= 0 ? 'text-emerald-300' : 'text-red-300'); ?> mt-2">
                    <?php echo e($persenChange >= 0 ? '↗' : '↘'); ?> <?php echo e(number_format(abs($persenChange), 1)); ?>% vs bln lalu
                </p>
            <?php else: ?>
                <p class="text-xs text-emerald-400 mt-2">Belum ada data perbandingan</p>
            <?php endif; ?>
            <p class="text-xs text-emerald-400 mt-1">Diperbarui: <?php echo e(now()->format('H:i')); ?></p>
        </div>

        
        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm px-5 py-5">
            <p class="text-xs text-slate-500 uppercase tracking-wider mb-2">Jumlah Produk Terjual</p>
            <p class="text-2xl font-bold text-slate-900 leading-tight">
                <?php echo e(number_format($jumlahTerjual, 0, ',', '.')); ?>

                <span class="text-sm font-medium text-slate-500">Unit</span>
            </p>
            <p class="text-xs font-medium text-emerald-600 mt-2">Bulan ini</p>
            <p class="text-xs text-slate-400 mt-1">Diperbarui: <?php echo e(now()->format('H:i')); ?></p>
        </div>

        
        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm px-5 py-5">
            <p class="text-xs text-slate-500 uppercase tracking-wider mb-2">Bahan Baku Aktif</p>
            <p class="text-2xl font-bold text-slate-900 leading-tight">
                <?php echo e($totalBahanBaku); ?> <span class="text-sm font-medium text-slate-500">Jenis</span>
            </p>
            <p class="text-xs font-medium text-emerald-600 mt-2">✓ Aktif dipantau</p>
            <p class="text-xs text-slate-400 mt-1">Diperbarui: <?php echo e(now()->format('H:i')); ?></p>
        </div>

        
        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm px-5 py-5">
            <p class="text-xs text-slate-500 uppercase tracking-wider mb-2">Kategori Produk</p>
            <p class="text-2xl font-bold text-slate-900 leading-tight">
                <?php echo e($totalKategori); ?> <span class="text-sm font-medium text-slate-500">Kategori</span>
            </p>
            <p class="text-xs font-medium text-emerald-600 mt-2">✓ Aktif</p>
            <p class="text-xs text-slate-400 mt-1">Diperbarui: <?php echo e(now()->format('H:i')); ?></p>
        </div>
    </div>

    
    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm px-6 py-5 mb-4">
        <h3 class="text-base font-bold text-slate-900">Tren Penjualan Harian</h3>
        <p class="text-xs text-slate-500 mb-5">Pendapatan per hari, <?php echo e(now()->translatedFormat('F Y')); ?></p>
        <?php if($trenValues->isEmpty()): ?>
            <div class="h-56 flex items-center justify-center text-sm text-slate-400">
                Belum ada penjualan bulan ini.
            </div>
        <?php else: ?>
            <div class="h-56"><canvas id="chartTren"></canvas></div>
        <?php endif; ?>
    </div>

    
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">

        <div class="lg:col-span-2 bg-white rounded-2xl border border-slate-200 shadow-sm px-6 py-5">
            <h3 class="text-base font-bold text-slate-900">Volume Penjualan Produk</h3>
            <p class="text-xs text-slate-500 mb-5">Performa per kategori produk bulan ini</p>
            <?php if($volumePerKategori->isEmpty()): ?>
                <div class="h-64 flex items-center justify-center text-sm text-slate-400">
                    Belum ada penjualan bulan ini.
                </div>
            <?php else: ?>
                <div class="h-64"><canvas id="chartVolume"></canvas></div>
            <?php endif; ?>
        </div>

        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm px-6 py-5">
            <h3 class="text-base font-bold text-slate-900">Distribusi Penjualan</h3>
            <p class="text-xs text-slate-500 mb-5">Per kategori produk</p>
            <?php if($distribusi->isEmpty()): ?>
                <div class="h-48 flex items-center justify-center text-sm text-slate-400">
                    Belum ada data.
                </div>
            <?php else: ?>
                <div class="h-44 mb-4 flex items-center justify-center">
                    <canvas id="chartDistribusi"></canvas>
                </div>
                <div class="space-y-2">
                    <?php $__currentLoopData = $distribusi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex items-center justify-between text-sm">
                            <div class="flex items-center gap-2">
                                <span class="w-2.5 h-2.5 rounded-full"
                                      style="background-color: <?php echo e(['#10b981','#34d399','#6ee7b7','#a7f3d0','#d1fae5'][$i % 5]); ?>">
                                </span>
                                <span class="text-slate-700"><?php echo e($item['kategori']); ?></span>
                            </div>
                            <span class="font-medium text-slate-900"><?php echo e($item['persen']); ?>%</span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php if($volumePerKategori->isNotEmpty() || $distribusi->isNotEmpty() || $trenValues->isNotEmpty()): ?>
        <script src="https://cdn.jsdelivr.net/npm/chart.js@4"></script>
        <script>
            const colors = ['#10b981','#34d399','#6ee7b7','#a7f3d0','#d1fae5'];

            <?php if($trenValues->isNotEmpty()): ?>
                new Chart(document.getElementById('chartTren'), {
                    type: 'line',
                    data: {
                        labels: <?php echo json_encode($trenLabels, 15, 512) ?>,
                        datasets: [{
                            label: 'Pendapatan',
                            data: <?php echo json_encode($trenValues, 15, 512) ?>,
                            borderColor: '#10b981',
                            backgroundColor: 'rgba(16, 185, 129, 0.08)',
                            fill: true,
                            tension: 0.35,
                            pointRadius: 2,
                            pointHoverRadius: 5,
                            borderWidth: 2
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { display: false },
                            tooltip: {
                                callbacks: {
                                    label: ctx => 'Rp ' + Math.round(ctx.parsed.y).toLocaleString('id-ID')
                                }
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    callback: v => 'Rp ' + (v >= 1000000
                                        ? (v/1000000).toFixed(1)+'jt'
                                        : (v/1000).toFixed(0)+'rb')
                                },
                                grid: { color: '#f1f5f9' }
                            },
                            x: {
                                grid: { display: false },
                                ticks: { maxTicksLimit: 12 }
                            }
                        }
                    }
                });
            <?php endif; ?>

            <?php if($volumePerKategori->isNotEmpty()): ?>
                new Chart(document.getElementById('chartVolume'), {
                    type: 'bar',
                    data: {
                        labels: <?php echo json_encode($volumePerKategori->pluck('kategori'), 15, 512) ?>,
                        datasets: [{
                            data: <?php echo json_encode($volumePerKategori->pluck('total'), 15, 512) ?>,
                            backgroundColor: colors,
                            borderRadius: 8,
                            maxBarThickness: 60
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { display: false } },
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    callback: v => 'Rp ' + (v >= 1000000
                                        ? (v/1000000).toFixed(1)+'jt'
                                        : (v/1000).toFixed(0)+'rb')
                                },
                                grid: { color: '#f1f5f9' }
                            },
                            x: { grid: { display: false } }
                        }
                    }
                });
            <?php endif; ?>

            <?php if($distribusi->isNotEmpty()): ?>
                new Chart(document.getElementById('chartDistribusi'), {
                    type: 'doughnut',
                    data: {
                        labels: <?php echo json_encode($distribusi->pluck('kategori'), 15, 512) ?>,
                        datasets: [{
                            data: <?php echo json_encode($distribusi->pluck('persen'), 15, 512) ?>,
                            backgroundColor: colors,
                            borderWidth: 0
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        cutout: '70%',
                        plugins: { legend: { display: false } }
                    }
                });
            <?php endif; ?>
        </script>
    <?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH C:\Users\ACER\Herd\segar-alami\resources\views/owner/dashboard.blade.php ENDPATH**/ ?>