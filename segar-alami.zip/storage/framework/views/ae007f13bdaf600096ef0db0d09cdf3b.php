<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title', 'subtitle' => null, 'expiredCount' => 0]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title', 'subtitle' => null, 'expiredCount' => 0]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php $user = auth()->user(); ?>

<header class="bg-slate-100 px-4 sm:px-6 lg:px-8 pt-5 sm:pt-6 pb-4 flex items-start justify-between gap-3">
    <div class="flex items-start gap-3 min-w-0">
        
        <button type="button" @click="sidebarOpen = true"
            class="lg:hidden mt-0.5 w-9 h-9 -ml-1 rounded-lg flex items-center justify-center text-slate-600 hover:bg-slate-200 transition shrink-0">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
            </svg>
        </button>
        <div class="min-w-0">
            <h1 class="text-xl sm:text-2xl font-bold text-slate-900 truncate"><?php echo e($title); ?></h1>
            <?php if($subtitle): ?>
                <p class="text-sm text-slate-500 mt-1 hidden sm:block"><?php echo e($subtitle); ?></p>
            <?php endif; ?>
        </div>
    </div>

    <div class="flex items-center gap-2 sm:gap-3 mt-1 shrink-0">

        <?php if($expiredCount > 0): ?>
            <a href="<?php echo e(route('app.bahan-masuk.index')); ?>"
                class="relative flex items-center justify-center w-9 h-9 rounded-full bg-red-50 border border-red-100 hover:bg-red-100 transition"
                title="<?php echo e($expiredCount); ?> bahan baku perlu diperhatikan">
                <svg class="w-4 h-4 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
                <span
                    class="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center leading-none">
                    <?php echo e($expiredCount > 9 ? '9+' : $expiredCount); ?>

                </span>
            </a>
        <?php endif; ?>

        <div class="text-right hidden sm:block">
            <p class="text-sm font-semibold text-slate-700"><?php echo e($user->name); ?></p>
            <p class="text-xs text-emerald-600 capitalize"><?php echo e($user->getRoleNames()->first()); ?></p>
        </div>
        <?php
            $initials = collect(explode(' ', $user->name))
                ->take(2)
                ->map(fn($w) => strtoupper($w[0]))
                ->join('');
        ?>
        <div
            class="w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold
            bg-emerald-500/[0.15] text-emerald-600 shrink-0">
            <?php echo e($initials); ?>

        </div>
        <div class="text-xs text-slate-400 border-l border-slate-200 pl-3 hidden md:block">
            <?php echo e(now()->translatedFormat('d M Y')); ?>

        </div>
    </div>
</header>
<?php /**PATH C:\Users\ACER\Herd\segar-alami\resources\views/components/admin/topbar.blade.php ENDPATH**/ ?>