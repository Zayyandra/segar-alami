<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['title' => 'Bahan Masuk','subtitle' => 'Monitoring arus bahan baku masuk ke gudang.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Bahan Masuk','subtitle' => 'Monitoring arus bahan baku masuk ke gudang.']); ?>

    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
            <div>
                <h3 class="text-sm font-bold text-slate-900">Stok Bahan Baku Masuk</h3>
                <p class="text-xs text-slate-400 mt-0.5">Monitoring arus masuk bahan baku secara real-time.</p>
            </div>
            <div class="flex items-center gap-3">
                <a href="<?php echo e(route('app.bahan-keluar.index')); ?>"
                    class="text-sm text-emerald-600 hover:text-emerald-700 font-medium">
                    Lihat Bahan Keluar →
                </a>
                <a href="<?php echo e(route('app.bahan-masuk.create')); ?>"
                    class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-medium transition">
                    + Catat Masuk
                </a>
            </div>
        </div>

        <div class="px-6 py-3 border-b border-slate-100 flex gap-3">
            <form method="GET" action="<?php echo e(route('app.bahan-masuk.index')); ?>" class="flex flex-1 gap-3 flex-wrap">
                <select name="bahan_baku_id" onchange="this.form.submit()"
                    class="min-w-[200px] px-3 py-2 rounded-lg border border-slate-200 text-sm bg-white focus:border-emerald-500 focus:outline-none">
                    <option value="">Semua Bahan Baku</option>
                    <?php $__currentLoopData = $bahanBakus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($bb->id); ?>" <?php if(request('bahan_baku_id') == $bb->id): echo 'selected'; endif; ?>><?php echo e($bb->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <input type="date" name="tanggal" value="<?php echo e(request('tanggal')); ?>" onchange="this.form.submit()"
                    class="px-3 py-2 rounded-lg border border-slate-200 text-sm bg-white focus:border-emerald-500 focus:outline-none">
                <?php if(request()->anyFilled(['bahan_baku_id', 'tanggal'])): ?>
                    <a href="<?php echo e(route('app.bahan-masuk.index')); ?>"
                        class="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-100 transition">Reset</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-slate-50">
                    <tr class="text-left text-xs uppercase tracking-wide text-slate-500">
                        <th class="px-6 py-3 font-medium">Bahan Baku</th>
                        <th class="px-6 py-3 font-medium">Vendor / Supplier</th>
                        <th class="px-6 py-3 font-medium text-right">Jumlah</th>
                        <th class="px-6 py-3 font-medium text-center">Lead Time</th>
                        <th class="px-6 py-3 font-medium">Tgl Kadaluarsa</th>
                        <th class="px-6 py-3 font-medium">Tanggal</th>
                        <th class="px-6 py-3 font-medium text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__empty_1 = true; $__currentLoopData = $bahanMasuks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $isKadaluarsa = $item->tanggal_kadaluarsa && $item->tanggal_kadaluarsa->isPast();
                            $mendekati =
                                $item->tanggal_kadaluarsa &&
                                !$isKadaluarsa &&
                                now()->diffInDays($item->tanggal_kadaluarsa, false) <= 7;
                        ?>
                        <tr
                            class="<?php echo e($isKadaluarsa ? 'bg-red-100' : ($mendekati ? 'bg-amber-100' : 'hover:bg-slate-50/50')); ?>">
                            <td class="px-6 py-4">
                                <p class="text-sm font-semibold text-slate-900"><?php echo e($item->bahanBaku->nama); ?></p>
                                <p class="text-xs text-slate-400"><?php echo e(ucfirst($item->bahanBaku->kategori_bb)); ?></p>
                            </td>
                            <td class="px-6 py-4 text-sm text-slate-600"><?php echo e($item->nama_supplier ?? '—'); ?></td>
                            <td class="px-6 py-4 text-right">
                                <span
                                    class="text-sm font-bold text-emerald-600 tabular-nums">+<?php echo e(number_format($item->jumlah, 0, ',', '.')); ?></span>
                                <span class="text-xs text-slate-400 ml-1"><?php echo e($item->bahanBaku->satuan); ?></span>
                            </td>
                            <td class="px-6 py-4 text-center text-sm text-slate-600">
                                <?php echo e($item->lead_time_hari !== null ? $item->lead_time_hari . ' hari' : '—'); ?>

                            </td>
                            <td class="px-6 py-4 text-sm">
                                <?php if($item->tanggal_kadaluarsa): ?>
                                    <?php if($isKadaluarsa): ?>
                                        <span class="text-red-600 font-semibold text-xs">⚠
                                            <?php echo e($item->tanggal_kadaluarsa->format('d M Y')); ?> (Kadaluarsa)</span>
                                    <?php elseif($mendekati): ?>
                                        <span class="text-amber-600 font-semibold text-xs">⚠
                                            <?php echo e($item->tanggal_kadaluarsa->format('d M Y')); ?></span>
                                    <?php else: ?>
                                        <span
                                            class="text-slate-600 text-xs"><?php echo e($item->tanggal_kadaluarsa->format('d M Y')); ?></span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="text-slate-300 text-xs">—</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 text-sm text-slate-500"><?php echo e($item->tanggal->format('d M Y')); ?></td>
                            <td class="px-6 py-4 text-right">
                                <div class="inline-flex items-center gap-3">
                                    <a href="<?php echo e(route('app.bahan-masuk.edit', $item)); ?>"
                                        class="text-sm font-medium text-emerald-600 hover:text-emerald-700">Edit</a>
                                    <form method="POST" action="<?php echo e(route('app.bahan-masuk.destroy', $item)); ?>"
                                        class="inline"
                                        data-confirm="Hapus data ini? Stok akan dikurangi <?php echo e(number_format($item->jumlah, 0)); ?> <?php echo e($item->bahanBaku->satuan); ?>.">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit"
                                            class="text-sm font-medium text-red-500 hover:text-red-600">Hapus</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="px-6 py-16 text-center text-sm text-slate-400">
                                Belum ada data bahan masuk.
                                <a href="<?php echo e(route('app.bahan-masuk.create')); ?>"
                                    class="text-emerald-600 hover:underline">Catat sekarang.</a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($bahanMasuks->hasPages()): ?>
            <div class="px-6 py-4 border-t border-slate-100"><?php echo e($bahanMasuks->links()); ?></div>
        <?php endif; ?>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH C:\Users\ACER\Herd\segar-alami\resources\views/admin/bahan-masuk/index.blade.php ENDPATH**/ ?>