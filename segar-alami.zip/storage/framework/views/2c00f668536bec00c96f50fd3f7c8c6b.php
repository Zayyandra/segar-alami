<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['title' => 'Catat Penjualan','subtitle' => 'Buat catatan transaksi penjualan baru untuk Segar Alami.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Catat Penjualan','subtitle' => 'Buat catatan transaksi penjualan baru untuk Segar Alami.']); ?>
    <div class="max-w-4xl mx-auto space-y-5">

        <?php if($errors->any()): ?>
            <div class="rounded-lg border border-red-100 bg-red-50 px-4 py-3 text-sm text-red-700">
                <p class="font-medium mb-1">Terdapat kesalahan:</p>
                <ul class="list-disc list-inside space-y-0.5">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('app.penjualan.store')); ?>">
            <?php echo csrf_field(); ?>

            <div class="bg-white rounded-2xl border border-slate-200 shadow-sm px-8 py-6">

                
                <div class="grid gap-5 md:grid-cols-2 pb-6 border-b border-slate-100">
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1.5">
                            Tanggal <span class="text-red-500">*</span>
                        </label>
                        <input type="date" name="tanggal" value="<?php echo e(old('tanggal', date('Y-m-d'))); ?>"
                            class="w-full rounded-lg border border-slate-200 px-3 py-2.5 text-sm
                                      focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1.5">
                            Keterangan <span class="text-xs text-slate-400 font-normal">(opsional)</span>
                        </label>
                        <input type="text" name="keterangan" value="<?php echo e(old('keterangan')); ?>"
                            placeholder="Contoh: Penjualan pagi hari"
                            class="w-full rounded-lg border border-slate-200 px-3 py-2.5 text-sm
                                      focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none">
                    </div>
                </div>

                
                <div class="pt-5">
                    <div class="flex items-center justify-between mb-4">
                        <h2 class="text-sm font-semibold text-slate-700 uppercase tracking-wider">Item Penjualan</h2>
                        <button type="button" id="btn-tambah-item"
                            class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-emerald-300
                                       text-emerald-700 text-sm font-medium hover:bg-emerald-50 transition">
                            + Tambah Item
                        </button>
                    </div>

                    <div class="overflow-x-auto -mx-2">
                        <table class="w-full min-w-[640px]">
                            <thead>
                                <tr
                                    class="text-left text-xs uppercase tracking-wide text-slate-400 border-b border-slate-100">
                                    <th class="px-2 py-2 font-medium w-[40%]">Produk / Varian</th>
                                    <th class="px-2 py-2 font-medium w-[15%]">Jumlah</th>
                                    <th class="px-2 py-2 font-medium w-[20%]">Harga Satuan</th>
                                    <th class="px-2 py-2 font-medium w-[20%] text-right">Subtotal</th>
                                    <th class="px-2 py-2 w-[5%]"></th>
                                </tr>
                            </thead>
                            <tbody id="item-container">
                                <tr class="item-row border-b border-slate-50">
                                    <td class="px-2 py-3">
                                        <select name="items[0][varian_produk_id]"
                                            class="varian-select w-full rounded-lg border border-slate-200 px-3 py-2 text-sm bg-white
                                                       focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none">
                                            <option value="">— Pilih varian —</option>
                                            <?php $__currentLoopData = $variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($v->id); ?>" data-harga="<?php echo e($v->harga); ?>">
                                                    <?php echo e($v->produk->nama); ?> —
                                                    <?php echo e($v->nama_varian); ?><?php echo e($v->ukuran ? ' (' . $v->ukuran . ')' : ''); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </td>
                                    <td class="px-2 py-3">
                                        <input type="number" name="items[0][jumlah]" value="1" min="1"
                                            class="jumlah-input w-full rounded-lg border border-slate-200 px-3 py-2 text-sm
                                                      focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none">
                                    </td>
                                    <td class="px-2 py-3">
                                        <input type="number" name="items[0][harga_satuan]" value=""
                                            min="0" step="1" placeholder="0"
                                            class="harga-input w-full rounded-lg border border-slate-200 px-3 py-2 text-sm
                                                      focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none">
                                    </td>
                                    <td class="px-2 py-3 text-right">
                                        <span class="subtotal-display text-sm font-medium text-slate-700">Rp 0</span>
                                    </td>
                                    <td class="px-2 py-3 text-center">
                                        <button type="button"
                                            class="btn-hapus-item text-slate-300 hover:text-red-500 transition text-lg leading-none">×</button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-5 pt-4 border-t border-slate-100 flex items-center justify-end gap-4">
                        <span class="text-sm font-medium text-slate-600">Total Transaksi</span>
                        <span id="grand-total" class="text-xl font-bold text-slate-900">Rp 0</span>
                    </div>
                </div>

                
                <div class="mt-6 pt-5 border-t border-slate-100 flex items-center justify-end gap-3">
                    <a href="<?php echo e(route('app.penjualan.index')); ?>"
                        class="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-100 transition">
                        Batal
                    </a>
                    <button type="submit"
                        class="px-6 py-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-medium transition">
                        Simpan Transaksi
                    </button>
                </div>
            </div>
        </form>
    </div>

    <script>
        let rowIndex = 1;

        const variantOptions = `
            <option value="">— Pilih varian —</option>
            <?php $__currentLoopData = $variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($v->id); ?>" data-harga="<?php echo e($v->harga); ?>"><?php echo e($v->produk->nama); ?> — <?php echo e($v->nama_varian); ?><?php echo e($v->ukuran ? ' (' . $v->ukuran . ')' : ''); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        `;

        function formatRupiah(number) {
            return 'Rp ' + Math.round(number).toLocaleString('id-ID');
        }

        function hitungSubtotal(row) {
            const jumlah = parseFloat(row.querySelector('.jumlah-input').value) || 0;
            const harga = parseFloat(row.querySelector('.harga-input').value) || 0;
            row.querySelector('.subtotal-display').textContent = formatRupiah(jumlah * harga);
            hitungTotal();
        }

        function hitungTotal() {
            let total = 0;
            document.querySelectorAll('.item-row').forEach(row => {
                const jumlah = parseFloat(row.querySelector('.jumlah-input').value) || 0;
                const harga = parseFloat(row.querySelector('.harga-input').value) || 0;
                total += jumlah * harga;
            });
            document.getElementById('grand-total').textContent = formatRupiah(total);
        }

        function attachRowEvents(row) {
            row.querySelector('.varian-select').addEventListener('change', function() {
                const harga = this.options[this.selectedIndex].dataset.harga || '';
                row.querySelector('.harga-input').value = harga;
                hitungSubtotal(row);
            });
            row.querySelector('.jumlah-input').addEventListener('input', () => hitungSubtotal(row));
            row.querySelector('.harga-input').addEventListener('input', () => hitungSubtotal(row));
            row.querySelector('.btn-hapus-item').addEventListener('click', function() {
                if (document.querySelectorAll('.item-row').length <= 1) return;
                row.remove();
                reindexRows();
                hitungTotal();
            });
        }

        function reindexRows() {
            document.querySelectorAll('.item-row').forEach((row, i) => {
                row.querySelector('.varian-select').name = `items[${i}][varian_produk_id]`;
                row.querySelector('.jumlah-input').name = `items[${i}][jumlah]`;
                row.querySelector('.harga-input').name = `items[${i}][harga_satuan]`;
            });
        }

        attachRowEvents(document.querySelector('.item-row'));

        document.getElementById('btn-tambah-item').addEventListener('click', function() {
            const tbody = document.getElementById('item-container');
            const tr = document.createElement('tr');
            tr.className = 'item-row border-b border-slate-50';
            tr.innerHTML = `
                <td class="px-2 py-3">
                    <select name="items[${rowIndex}][varian_produk_id]"
                            class="varian-select w-full rounded-lg border border-slate-200 px-3 py-2 text-sm bg-white
                                   focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none">
                        ${variantOptions}
                    </select>
                </td>
                <td class="px-2 py-3">
                    <input type="number" name="items[${rowIndex}][jumlah]" value="1" min="1"
                           class="jumlah-input w-full rounded-lg border border-slate-200 px-3 py-2 text-sm
                                  focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none">
                </td>
                <td class="px-2 py-3">
                    <input type="number" name="items[${rowIndex}][harga_satuan]" value="" min="0" step="1" placeholder="0"
                           class="harga-input w-full rounded-lg border border-slate-200 px-3 py-2 text-sm
                                  focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none">
                </td>
                <td class="px-2 py-3 text-right">
                    <span class="subtotal-display text-sm font-medium text-slate-700">Rp 0</span>
                </td>
                <td class="px-2 py-3 text-center">
                    <button type="button" class="btn-hapus-item text-slate-300 hover:text-red-500 transition text-lg leading-none">×</button>
                </td>
            `;
            tbody.appendChild(tr);
            attachRowEvents(tr);
            rowIndex++;
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH C:\Users\ACER\Herd\segar-alami\resources\views/admin/penjualan/create.blade.php ENDPATH**/ ?>