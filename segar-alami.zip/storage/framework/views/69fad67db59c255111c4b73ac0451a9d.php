<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title' => null, 'subtitle' => null, 'action' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title' => null, 'subtitle' => null, 'action' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div <?php echo e($attributes->merge(['class' => 'bg-white rounded-xl border border-slate-200 overflow-hidden'])); ?>>
    <?php if($title || $action): ?>
        <div class="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
            <div>
                <?php if($title): ?><h2 class="text-lg font-semibold text-slate-900"><?php echo e($title); ?></h2><?php endif; ?>
                <?php if($subtitle): ?><p class="text-sm text-slate-500 mt-0.5"><?php echo e($subtitle); ?></p><?php endif; ?>
            </div>
            <?php if($action): ?><div><?php echo e($action); ?></div><?php endif; ?>
        </div>
    <?php endif; ?>
    <div><?php echo e($slot); ?></div>
</div>
<?php /**PATH C:\Users\ACER\Herd\segar-alami\resources\views/components/admin/card.blade.php ENDPATH**/ ?>