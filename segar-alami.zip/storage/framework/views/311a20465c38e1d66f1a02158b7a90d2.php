<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'label',
    'name',
    'options' => [],
    'value' => null,
    'required' => false,
    'placeholder' => '-- Pilih --',
    'optionValue' => 'id',
    'optionLabel' => 'nama',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'label',
    'name',
    'options' => [],
    'value' => null,
    'required' => false,
    'placeholder' => '-- Pilih --',
    'optionValue' => 'id',
    'optionLabel' => 'nama',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div>
    <label for="<?php echo e($name); ?>" class="block text-sm font-medium text-slate-700 mb-1.5">
        <?php echo e($label); ?><?php if($required): ?> <span class="text-red-500">*</span><?php endif; ?>
    </label>
    <select
        name="<?php echo e($name); ?>"
        id="<?php echo e($name); ?>"
        <?php if($required): ?> required <?php endif; ?>
        class="block w-full rounded-lg border-slate-300 text-sm shadow-sm focus:border-primary-500 focus:ring-primary-500 <?php echo e($errors->has($name) ? 'border-red-300 focus:border-red-500 focus:ring-red-500' : ''); ?>"
    >
        <option value=""><?php echo e($placeholder); ?></option>
        <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $val = is_array($option) ? $option[$optionValue] : $option->{$optionValue};
                $lbl = is_array($option) ? $option[$optionLabel] : $option->{$optionLabel};
            ?>
            <option value="<?php echo e($val); ?>" <?php if(old($name, $value) == $val): echo 'selected'; endif; ?>><?php echo e($lbl); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="mt-1.5 text-xs text-red-600"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH C:\Users\ACER\Herd\segar-alami\resources\views/components/admin/select.blade.php ENDPATH**/ ?>