<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['title' => 'Bahan Keluar','subtitle' => 'Monitoring pemakaian bahan baku untuk produksi.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Bahan Keluar','subtitle' => 'Monitoring pemakaian bahan baku untuk produksi.']); ?>

    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
            <div>
                <h3 class="text-sm font-bold text-slate-900">Stok Bahan Baku Keluar</h3>
                <p class="text-xs text-slate-400 mt-0.5">Monitoring pemakaian bahan baku secara real-time.</p>
            </div>
            <div class="flex items-center gap-3">
                <a href="<?php echo e(route('app.bahan-masuk.index')); ?>"
                   class="text-sm text-emerald-600 hover:text-emerald-700 font-medium">
                   Lihat Bahan Masuk →
                </a>
                <a href="<?php echo e(route('app.bahan-keluar.create')); ?>"
                   class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-medium transition">
                    + Catat Keluar
                </a>
            </div>
        </div>

        <div class="px-6 py-3 border-b border-slate-100 flex gap-3">
            <form method="GET" action="<?php echo e(route('app.bahan-keluar.index')); ?>" class="flex flex-1 gap-3 flex-wrap">
                <select name="bahan_baku_id" onchange="this.form.submit()"
                    class="min-w-[200px] px-3 py-2 rounded-lg border border-slate-200 text-sm bg-white focus:border-emerald-500 focus:outline-none">
                    <option value="">Semua Bahan Baku</option>
                    <?php $__currentLoopData = $bahanBakus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($bb->id); ?>" <?php if(request('bahan_baku_id') == $bb->id): echo 'selected'; endif; ?>><?php echo e($bb->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <input type="date" name="tanggal" value="<?php echo e(request('tanggal')); ?>" onchange="this.form.submit()"
                    class="px-3 py-2 rounded-lg border border-slate-200 text-sm bg-white focus:border-emerald-500 focus:outline-none">
                <?php if(request()->anyFilled(['bahan_baku_id', 'tanggal'])): ?>
                    <a href="<?php echo e(route('app.bahan-keluar.index')); ?>" class="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-100 transition">Reset</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-slate-50">
                    <tr class="text-left text-xs uppercase tracking-wide text-slate-500">
                        <th class="px-6 py-3 font-medium">Bahan Baku</th>
                        <th class="px-6 py-3 font-medium text-right">Jumlah Keluar</th>
                        <th class="px-6 py-3 font-medium">Keterangan</th>
                        <th class="px-6 py-3 font-medium">Dicatat Oleh</th>
                        <th class="px-6 py-3 font-medium">Tanggal</th>
                        <th class="px-6 py-3 font-medium text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__empty_1 = true; $__currentLoopData = $bahanKeluars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-slate-50/50">
                            <td class="px-6 py-4">
                                <p class="text-sm font-semibold text-slate-900"><?php echo e($item->bahanBaku->nama); ?></p>
                                <p class="text-xs text-slate-400"><?php echo e(ucfirst($item->bahanBaku->kategori_bb)); ?></p>
                            </td>
                            <td class="px-6 py-4 text-right">
                                <span class="text-sm font-bold text-red-500 tabular-nums">−<?php echo e(number_format($item->jumlah, 0, ',', '.')); ?></span>
                                <span class="text-xs text-slate-400 ml-1"><?php echo e($item->bahanBaku->satuan); ?></span>
                            </td>
                            <td class="px-6 py-4 text-sm text-slate-600"><?php echo e($item->keterangan ?? '—'); ?></td>
                            <td class="px-6 py-4 text-sm text-slate-500"><?php echo e($item->user->name ?? '—'); ?></td>
                            <td class="px-6 py-4 text-sm text-slate-500"><?php echo e($item->tanggal->format('d M Y')); ?></td>
                            <td class="px-6 py-4 text-right">
                                <div class="inline-flex items-center gap-3">
                                    <a href="<?php echo e(route('app.bahan-keluar.edit', $item)); ?>" class="text-sm font-medium text-emerald-600 hover:text-emerald-700">Edit</a>
                                    <form method="POST" action="<?php echo e(route('app.bahan-keluar.destroy', $item)); ?>" class="inline"
                                          data-confirm="Hapus? Stok akan dikembalikan <?php echo e(number_format($item->jumlah, 0)); ?> <?php echo e($item->bahanBaku->satuan); ?>.">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-sm font-medium text-red-500 hover:text-red-600">Hapus</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="px-6 py-16 text-center text-sm text-slate-400">
                                Belum ada data bahan keluar.
                                <a href="<?php echo e(route('app.bahan-keluar.create')); ?>" class="text-emerald-600 hover:underline">Catat sekarang.</a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($bahanKeluars->hasPages()): ?>
            <div class="px-6 py-4 border-t border-slate-100"><?php echo e($bahanKeluars->links()); ?></div>
        <?php endif; ?>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH C:\Users\ACER\Herd\segar-alami\resources\views/admin/bahan-keluar/index.blade.php ENDPATH**/ ?>