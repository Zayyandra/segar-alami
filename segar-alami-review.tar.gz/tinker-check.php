<?php
$variants = App\Models\VarianProduk::with('produk')->get();
foreach ($variants as $v) {
    echo $v->produk->nama . ' | ' . $v->nama_varian . ' | ' . ($v->ukuran ?? 'null') . "\n";
}
