<?php

/**
 * Segar Alami — Pre-Sidang System Check
 * Jalankan dari root project: php check.php
 */

define('ROOT', __DIR__);
$pass = 0;
$fail = 0;
$warn = 0;
$results = [];

// ─── Helper ───────────────────────────────────────────────────────────────────

function check(string $label, bool $ok, string $detail = '', string $type = 'check'): void {
    global $pass, $fail, $warn, $results;
    if ($type === 'warn') {
        $icon  = "\033[33m⚠ WARN \033[0m";
        $warn++;
    } elseif ($ok) {
        $icon  = "\033[32m✔ PASS \033[0m";
        $pass++;
    } else {
        $icon  = "\033[31m✘ FAIL \033[0m";
        $fail++;
    }
    $results[] = [$icon, $label, $detail];
    echo $icon . $label . ($detail ? "\n       → " . $detail : '') . "\n";
}

function section(string $title): void {
    echo "\n\033[1;36m══ " . strtoupper($title) . " ══\033[0m\n";
}

function fileContains(string $file, string $needle): bool {
    if (!file_exists($file)) return false;
    return str_contains(file_get_contents($file), $needle);
}

function fileNotContains(string $file, string $needle): bool {
    if (!file_exists($file)) return true;
    return !str_contains(file_get_contents($file), $needle);
}

function readFile(string $file): string {
    return file_exists($file) ? file_get_contents($file) : '';
}

// ─── ENV ──────────────────────────────────────────────────────────────────────

section('1. Konfigurasi .env');

$env = file_exists(ROOT . '/.env') ? file_get_contents(ROOT . '/.env') : '';

preg_match('/APP_DEBUG\s*=\s*(\w+)/', $env, $m);
$debugVal = $m[1] ?? 'tidak ditemukan';
check(
    'APP_DEBUG=false',
    strtolower($debugVal) === 'false',
    "Nilai saat ini: APP_DEBUG=$debugVal" . (strtolower($debugVal) !== 'false' ? '  ← GANTI ke false sebelum sidang!' : '')
);

preg_match('/APP_URL\s*=\s*(.+)/', $env, $m2);
$appUrl = trim($m2[1] ?? '');
check(
    'APP_URL terdefinisi',
    !empty($appUrl),
    "Nilai saat ini: $appUrl",
    'warn'
);

// ─── ROUTES ───────────────────────────────────────────────────────────────────

section('2. Routes');

$webRoutes = readFile(ROOT . '/routes/web.php');

check(
    'Route destroy penjualan sudah dihapus',
    !preg_match('/penjualan.*destroy|destroy.*penjualan/i', $webRoutes) &&
    !str_contains($webRoutes, "'penjualan')->resource") ||
    (str_contains($webRoutes, 'penjualan') && str_contains($webRoutes, "->except(['destroy']")),
    str_contains($webRoutes, "->except(['destroy']") ? "except destroy ditemukan ✔" : "Periksa manual apakah route destroy ada"
);

check(
    'Route safety-stock.index sudah dihapus',
    !str_contains($webRoutes, 'safety-stock'),
    str_contains($webRoutes, 'safety-stock') ? "Masih ada! Hapus route ini." : ''
);

check(
    'Middleware role terpasang (Spatie)',
    str_contains($webRoutes, 'role:') || str_contains($webRoutes, "'role'") || str_contains($webRoutes, 'role:admin') || str_contains($webRoutes, 'role:owner'),
    str_contains($webRoutes, 'role:') ? "Middleware role ditemukan ✔" : "Tidak ditemukan middleware role di web.php"
);

// ─── CONTROLLERS ──────────────────────────────────────────────────────────────

section('3. Controllers');

$penjualanCtrl = readFile(ROOT . '/app/Http/Controllers/Admin/PenjualanController.php');
check(
    'PenjualanController: method destroy dihapus',
    !str_contains($penjualanCtrl, 'function destroy'),
    str_contains($penjualanCtrl, 'function destroy') ? "Method destroy masih ada!" : ''
);
check(
    'PenjualanController: method update/edit ada',
    str_contains($penjualanCtrl, 'function edit') || str_contains($penjualanCtrl, 'function update'),
    ''
);

$dashCtrl = readFile(ROOT . '/app/Http/Controllers/Admin/DashboardController.php');
check(
    'DashboardController: produkTerjualBulanIni ada',
    str_contains($dashCtrl, 'produkTerjualBulanIni') || str_contains($dashCtrl, 'produk_terjual'),
    str_contains($dashCtrl, 'produkTerjualBulanIni') ? '' : "Variabel tidak ditemukan di DashboardController"
);
check(
    'DashboardController: Cache::remember dihapus dari volumePerKategori',
    !str_contains($dashCtrl, "Cache::remember") ||
    !preg_match('/Cache::remember.*volumePerKategori|volumePerKategori.*Cache::remember/s', $dashCtrl),
    str_contains($dashCtrl, 'Cache::remember') ? "Masih ada Cache::remember — cek apakah di volumePerKategori" : ''
);

$bahanBakuCtrl = readFile(ROOT . '/app/Http/Controllers/Admin/BahanBakuController.php');
check(
    'BahanBakuController: kalkulasi SS/ROP ada',
    str_contains($bahanBakuCtrl, 'safety_stock') || str_contains($bahanBakuCtrl, 'safetyStock') || str_contains($bahanBakuCtrl, 'ss ') || str_contains($bahanBakuCtrl, '$ss'),
    ''
);

$laporanCtrl = readFile(ROOT . '/app/Http/Controllers/Owner/LaporanPenjualanController.php');
if (!file_exists(ROOT . '/app/Http/Controllers/Owner/LaporanPenjualanController.php')) {
    $laporanCtrl = readFile(ROOT . '/app/Http/Controllers/Admin/LaporanPenjualanController.php');
}
check(
    'LaporanPenjualanController: $produkTerlaris dihapus',
    !str_contains($laporanCtrl, 'produkTerlaris') && !str_contains($laporanCtrl, 'produk_terlaris'),
    str_contains($laporanCtrl, 'produkTerlaris') ? "Masih ada \$produkTerlaris!" : ''
);

// ─── VIEWS ────────────────────────────────────────────────────────────────────

section('4. Views — Blade Files');

// Admin dashboard
$adminDash = readFile(ROOT . '/resources/views/admin/dashboard.blade.php');
check(
    'Admin dashboard: produkTerjualBulanIni dirender',
    str_contains($adminDash, 'produkTerjualBulanIni') || str_contains($adminDash, 'produk_terjual'),
    ''
);
check(
    'Admin dashboard: label pakai Bahasa Indonesia',
    !preg_match('/\b(Revenue|Sales|Delete|Edit|Update|Submit|Search|Filter|Export|Stock|Product|Category|Material)\b/', $adminDash),
    ''
);

// Penjualan index
$penjualanView = readFile(ROOT . '/resources/views/admin/penjualan/index.blade.php');
check(
    'Penjualan index: tombol/form DELETE dihapus',
    !str_contains($penjualanView, "method('DELETE')") && !str_contains($penjualanView, '@method(\'DELETE\')') && !str_contains($penjualanView, 'method="DELETE"'),
    str_contains($penjualanView, 'DELETE') ? "Masih ada referensi DELETE!" : ''
);
check(
    'Penjualan index: link/tombol edit ada',
    str_contains($penjualanView, 'edit') || str_contains($penjualanView, 'Edit'),
    ''
);

// Bahan baku index
$bahanBakuView = readFile(ROOT . '/resources/views/admin/bahan-baku/index.blade.php');
check(
    'Bahan Baku: kolom Safety Stock tampil',
    str_contains($bahanBakuView, 'safety_stock') || str_contains($bahanBakuView, 'safetyStock') || str_contains($bahanBakuView, 'Safety Stock'),
    ''
);
check(
    'Bahan Baku: kolom ROP tampil',
    str_contains($bahanBakuView, 'rop') || str_contains($bahanBakuView, 'ROP'),
    ''
);
check(
    'Bahan Baku: keterangan rumus ada',
    str_contains($bahanBakuView, 'SS =') || str_contains($bahanBakuView, 'ROP =') || str_contains($bahanBakuView, 'rumus') || str_contains($bahanBakuView, 'Rumus'),
    ''
);

// Laporan penjualan owner
$laporanView = readFile(ROOT . '/resources/views/owner/laporan-penjualan.blade.php');
check(
    'Laporan Penjualan: chart/canvas dihapus dari view',
    !str_contains($laporanView, '<canvas') && !str_contains($laporanView, 'chart') && !str_contains($laporanView, 'Chart'),
    str_contains($laporanView, 'canvas') ? "Masih ada <canvas> → chart belum dihapus" : ''
);
check(
    'Laporan Penjualan: tabel transaksi ada',
    str_contains($laporanView, '<table') || str_contains($laporanView, 'transaksi') || str_contains($laporanView, 'penjualan'),
    ''
);

// PDF view
$pdfView = readFile(ROOT . '/resources/views/owner/pdf/laporan-penjualan.blade.php');
check(
    'PDF Laporan: $produkTerlaris tidak direferensi',
    !str_contains($pdfView, 'produkTerlaris') && !str_contains($pdfView, 'produk_terlaris'),
    str_contains($pdfView, 'produkTerlaris') ? "Masih ada \$produkTerlaris di PDF blade!" : ''
);

// Owner dashboard
$ownerDash = readFile(ROOT . '/resources/views/owner/dashboard.blade.php');
check(
    'Owner dashboard: chart laporan penjualan tidak ada',
    !str_contains($ownerDash, 'laporan') || !str_contains($ownerDash, '<canvas'),
    ''
);
check(
    'Owner dashboard: teks "Operational Hub" diganti',
    !str_contains($ownerDash, 'Operational Hub'),
    str_contains($ownerDash, 'Operational Hub') ? "Masih ada teks 'Operational Hub'" : ''
);

// Error pages
foreach (['403', '404', '500'] as $code) {
    $errView = readFile(ROOT . "/resources/views/errors/{$code}.blade.php");
    check(
        "Error page {$code} sudah dikustomisasi",
        !empty($errView) && strlen($errView) > 200,
        empty($errView) ? "File tidak ditemukan!" : ''
    );
}

// ─── BAHASA INGGRIS TERSISA ────────────────────────────────────────────────────

section('5. Scan Teks Bahasa Inggris di Views');

$viewsDir   = ROOT . '/resources/views';
$englishRe  = '/\b(Delete|Submit|Cancel|Back|Search|Filter|Export|Revenue|Stock\s+Status|Add\s+New|Edit\s+Data|Save\s+Changes|Confirm|Close|Loading)\b/';
$flagged    = [];

$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($viewsDir));
foreach ($iterator as $file) {
    if ($file->getExtension() !== 'php') continue;
    $content = file_get_contents($file->getPathname());
    // Abaikan komentar dan string PHP
    if (preg_match($englishRe, $content, $m)) {
        $rel = str_replace(ROOT . '/resources/views/', '', $file->getPathname());
        $flagged[] = $rel . ' → "' . $m[0] . '"';
    }
}

if (empty($flagged)) {
    check('Tidak ada teks Inggris umum terdeteksi di views', true, '');
} else {
    foreach ($flagged as $f) {
        check('Teks Inggris terdeteksi', false, $f);
    }
}

// ─── BOOTSTRAP / MIDDLEWARE ───────────────────────────────────────────────────

section('6. Bootstrap & Middleware');

$bootstrap = readFile(ROOT . '/bootstrap/app.php');
check(
    'Spatie role middleware terdaftar di bootstrap/app.php',
    str_contains($bootstrap, 'RoleMiddleware') || str_contains($bootstrap, 'role') && str_contains($bootstrap, 'middleware'),
    ''
);

// ─── DATABASE ─────────────────────────────────────────────────────────────────

section('7. Database');

$dbPath = ROOT . '/database/database.sqlite';
check(
    'File SQLite ada',
    file_exists($dbPath),
    file_exists($dbPath) ? 'database.sqlite ditemukan ✔' : 'database.sqlite tidak ada!'
);

if (file_exists($dbPath)) {
    $size = filesize($dbPath);
    check(
        'Database tidak kosong (ada data)',
        $size > 50000,
        'Ukuran: ' . round($size / 1024, 1) . ' KB' . ($size < 50000 ? ' — terlalu kecil, mungkin kosong' : '')
    );
}

// ─── RINGKASAN ────────────────────────────────────────────────────────────────

echo "\n\033[1;37m══════════════════════════════════════════\033[0m\n";
echo "\033[1;32m  PASS: $pass\033[0m  ";
echo "\033[1;31m  FAIL: $fail\033[0m  ";
echo "\033[1;33m  WARN: $warn\033[0m\n";
echo "\033[1;37m══════════════════════════════════════════\033[0m\n";

echo "\n\033[1;35m── Checklist Manual (tidak bisa dicek otomatis) ──\033[0m\n";
$manual = [
    '[ ] Login admin → buka /app/users → harus muncul 403',
    '[ ] Login owner → buka /app/penjualan → harus muncul 403',
    '[ ] Dashboard admin: kartu pendapatan tampilkan nama bulan berjalan',
    '[ ] Dashboard owner: tidak ada chart laporan penjualan',
    '[ ] Export PDF laporan penjualan berhasil (tidak 500)',
    '[ ] Ada transaksi bulan ini (supaya dashboard tidak Rp 0)',
    '[ ] Ada bahan masuk dengan tanggal_kadaluarsa (test notif expired)',
    '[ ] APP_URL di .env sudah diganti ke URL ngrok sebelum demo',
];
foreach ($manual as $item) {
    echo "  $item\n";
}
echo "\n";
